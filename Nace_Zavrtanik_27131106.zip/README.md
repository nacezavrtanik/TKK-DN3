﻿# 3. domača naloga (TKK)

Navodila:

1. Zaženi '1_generiraj_DSA'.
2. Zaženi '2_generiraj_blok'.
3. Po želji ponavljaj 2. korak.

Git: https://github.com/nacezavrtanik/TKK-DN3